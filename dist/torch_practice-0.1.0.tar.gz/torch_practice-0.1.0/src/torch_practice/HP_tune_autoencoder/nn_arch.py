import torch
from torch import Tensor, nn


class Encoder(nn.Module):
    """Define the Encoder part of the network."""

    def __init__(self) -> None:
        super().__init__()
        self.conv1 = nn.Conv2d(in_channels=3, out_channels=6, kernel_size=5)
        self.pool = nn.MaxPool2d(kernel_size=2, stride=2)
        self.conv2 = nn.Conv2d(in_channels=6, out_channels=16, kernel_size=5)

    def forward(self, x: Tensor) -> Tensor:
        """Forward pass for Encoding."""
        x = self.pool(self.ReLU(self.conv1(x)))
        x = self.pool(self.ReLU(self.conv2(x)))
        # Reuse this in the Decoder
        self.reshape_x = x.shape
        return self.flatten(x)


class Decoder(nn.Module):
    """Define the Decoder part of the network."""

    def __init__(self, reshape_x: torch.Size) -> None:
        super().__init__()
        self.conv1 = nn.Conv2d(in_channels=16, out_channels=6, kernel_size=5)
        self.pool = nn.MaxUnpool2d(kernel_size=2, stride=2)
        self.conv1 = nn.Conv2d(in_channels=6, out_channels=3, kernel_size=5)
        self.reshape_x = reshape_x

    def forward(self, x: Tensor) -> Tensor:
        """Forward pass for Decoding."""
        x = x.reshape(tuple(self.reshape_x))  # 16 channels
        x = self.pool(self.ReLU(self.conv1(x)))  # 6
        return self.pool(self.ReLU(self.conv2(x)))  # 3


class AE(nn.Module):
    """Auto Encoder for simple Images."""

    def __init__(self) -> None:
        super().__init__()
        self.Encoder = Encoder
        self.Decoder = Decoder

    def forward(self, x: Tensor) -> Tensor:
        """Forward Pass for AE."""
        encoder = Encoder()
        x = encoder.forward(x)
        decoder = Decoder(reshape_x=encoder.reshape_x)
        return decoder.forward(x)
