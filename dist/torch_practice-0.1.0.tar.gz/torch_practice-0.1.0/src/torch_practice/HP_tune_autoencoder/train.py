def train(epochs:int)->None:
  for i in range(epochs):
    # train, eval = data
    
