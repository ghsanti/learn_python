import torch
import torch.nn.functional as F
from torch import Tensor, nn

from torch_practice.HP_tune_autoencoder.main_types import DAEConfig


class DynamicEncoder(nn.Module):
    """Encoder.

    Args:
        increments: list of input_channel-output_channel tuples.
        config: parameters for layers configuration.

    """

    def __init__(self, increments: list[tuple[int, int]], config: DAEConfig) -> None:
        super().__init__()
        self.config = config
        self.pool = (
            nn.MaxPool2d(
                kernel_size=config.get("p_kernel"),
                stride=config.get("p_stride"),
                return_indices=True,
            )
            if self.config.get("use_pool")
            else None
        )
        c, b = create_layers(
            channels_list=increments,
            is_transpose=False,
            config=config,
        )
        self.convs = c
        self.batch_norms = b
        self.drop = nn.Dropout(0.3)
        self.dense = None

    def forward(
        self,
        x: Tensor,
    ) -> tuple[Tensor, list[Tensor], list[tuple[str, torch.Size]]]:
        """Forward pass for Encoding.

        Returns:
            x: Tensor
            indices: From the convolution
            shapes: before each pooling, and before flattening.

        """
        pool_indices = []
        shapes = []
        for c, b in zip(self.convs, self.batch_norms, strict=False):
            shapes.append(("conv", x.size()))
            x = self.drop(F.leaky_relu(b(c(x))))
            if self.pool is not None:
                shapes.append(("pool", x.size()))
                x, index = self.pool(x)
                pool_indices.append(index)
        shapes.append(("none", x.size()))  # unflattened size.
        x = x.view(x.size(0), -1)
        dense_i, dense_o = sum(x.shape[1:]), 128
        if self.dense is None:
            self.dense = nn.Linear(dense_i, dense_o)
        x = self.drop(nn.functional.leaky_relu(self.dense(x)))
        shapes.append(("dense", (dense_i, dense_o)))

        return x, pool_indices, shapes


class DynamicDecoder(nn.Module):
    """Create a flexible Decoder.

    Arguments:
        decrements: reversed increments.

    """

    def __init__(
        self,
        decrements: list[tuple[int, int]],
        config: DAEConfig,
    ) -> None:
        super().__init__()
        self.config = config
        self.unpool = (
            nn.MaxUnpool2d(
                stride=config.get("p_stride"),
                kernel_size=config.get("p_kernel"),
            )
            if self.config.get("use_pool")
            else None
        )
        tconvs, batch_norms = create_layers(
            channels_list=decrements,
            config=config,
            is_transpose=True,
        )
        self.drop = nn.Dropout(0.3)
        self.tconvs = tconvs
        self.batch_norms = batch_norms
        self.dense = None

    def forward(
        self,
        x: Tensor,
        indices: list[Tensor],
        shapes: list[tuple[str, torch.Size]],
    ) -> Tensor:
        """Decode.

        Note: indices are not reversed. We loop backwards.
        """
        c, p = -1, -1  # convolutional layer index.
        for i in range(len(shapes) - 1, -1, -1):
            name, shape = shapes[i]
            if i == 0 and name == "conv":
                # no relus for exit layer.
                conv, batch = self.tconvs[c], self.batch_norms[c]
                x = self.drop(batch(conv(x, output_size=shape)))
                break
            if name == "none":
                x = x.view(-1, *shape[1:])  # unflatten
            elif self.unpool is not None and name == "pool":
                x = self.unpool(x, indices[p], output_size=shape)
                p -= 1
            elif name == "conv":
                conv, batch = self.tconvs[c], self.batch_norms[c]
                x = self.drop(F.leaky_relu(batch(conv(x, output_size=shape))))
                c -= 1
            elif name == "dense":
                if self.dense is None:
                    self.dense = nn.Linear(shape[1], shape[0])
                x = self.drop(nn.functional.leaky_relu(self.dense(x)))

        return x


class DynamicAE(nn.Module):
    """Auto Encoder for simple Images."""

    def __init__(
        self,
        config: DAEConfig,
    ) -> None:
        super().__init__()
        self.increments: list[tuple[int, int]] = []
        self.config = config
        in_channels = config.get("in_channels")
        o_channels = config.get("init_out_channels")
        growth = config.get("growth")
        for _i in range(config.get("layers")):
            self.increments.append((in_channels, o_channels))
            in_channels = o_channels
            o_channels = int(round(o_channels * growth))

        self.encoder = DynamicEncoder(
            self.increments,
            self.config,
        )
        self.decoder = None

    def forward(self, x: Tensor) -> Tensor:
        """Forward Pass for AE."""
        x_encoded, pool_indices, shapes = self.encoder(x)
        if self.decoder is None:
            self.decoder = DynamicDecoder(self.increments, self.config)
        return self.decoder(x=x_encoded, indices=pool_indices, shapes=shapes)


def create_layers(
    channels_list: list[tuple[int, int]],
    config: DAEConfig,
    *,
    is_transpose: bool,
) -> tuple[nn.ModuleList, nn.ModuleList]:
    """Create the list of equivalent layers for each network.

    Args:
        channels_list: for transpose, must be the reversed (copy, not mutated.)list.
        config: layer parameters.
        is_transpose: whether we are making the transposed convolutions.

    """
    convs = nn.ModuleList()
    batch = nn.ModuleList()
    if is_transpose:
        for in_dim, out_dim in channels_list:
            convs.append(
                nn.ConvTranspose2d(
                    in_channels=out_dim,
                    out_channels=in_dim,
                    kernel_size=config.get("c_kernel"),
                    stride=config.get("c_stride"),
                ),
            )
            batch.append(nn.BatchNorm2d(in_dim))
        return convs, batch
    for in_dim, out_dim in channels_list:
        convs.append(
            nn.Conv2d(
                in_channels=in_dim,
                out_channels=out_dim,
                kernel_size=config.get("c_kernel"),
                stride=config.get("c_stride"),
            ),
        )
        batch.append(nn.BatchNorm2d(out_dim))
    return convs, batch


if __name__ == "__main__":
    from torchinfo import summary

    config: DAEConfig = {
        "c_kernel": 2,
        "c_stride": 1,
        "growth": 2,
        "in_channels": 3,
        "init_out_channels": 12,
        "layers": 4,
        "lr": 0.1,
        "batch_size": 18,
        "use_pool": True,
        "p_kernel": 2,
        "p_stride": 2,
    }

    model = DynamicAE(config)  # Replace with your model
    model(torch.rand((1, 3, 32, 32)))
    summary(model, input_size=(1, 3, 32, 32), device="cpu")
