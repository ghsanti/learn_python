from typing import TypedDict


class DAEConfig(TypedDict):
    """Configuration Dictionary for DAE params."""

    p_kernel: int  # Kernel size for pooling layers.
    p_stride: int  # Stride for pooling layers.
    c_kernel: int  # Kernel size for convolution layers.
    c_stride: int  # Stride for convolution layers.
    layers: int  # Number of layers in the encoder/decoder.
    growth: float  # Growth factor for channels across layers.
    in_channels: int  # Number of input channels (e.g., 3 for RGB images).
    lr: float  # learning rate
    init_out_channels: int  # initial output channels (1st conv.)
    batch_size: int
    use_pool: bool
